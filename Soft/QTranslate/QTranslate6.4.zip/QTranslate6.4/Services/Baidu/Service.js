function serviceHeader(){return new ServiceHeader(28,"Baidu","Baidu Translate is a free online translation service."+Const.NL2+"http://fanyi.baidu.com/"+Const.NL2+"\u00a9 2017 Baidu",Capability.TRANSLATE|Capability.DETECT_LANGUAGE|Capability.LISTEN)}function serviceHost(a,b,c){return a===Capability.LISTEN?"http://tts.baidu.com/":"http://fanyi.baidu.com"}
function serviceLink(a,b,c){var e="http://fanyi.baidu.com/";a&&(b=isLanguage(b)?codeFromLanguage(b):"auto",c=isLanguage(c)?codeFromLanguage(c):"auto",e+=format("#{0}/{1}/{2}",b,c,encodeGetParam(a)));return e}SupportedLanguages=[-1,-1,-1,-1,-1,"ara",-1,-1,-1,"bul",-1,"zh","cht",-1,"cs","dan","nl","en","est","fin",-1,"fra",-1,"de","el",-1,-1,-1,"hu",-1,-1,"it",-1,"jp",-1,"kor",-1,-1,-1,-1,-1,-1,-1,"pl","pt","rom","ru",-1,-1,"slo","spa",-1,"swe","th",-1,-1,-1,"vie",-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];
function serviceDetectLanguageRequest(a){a="query="+encodeGetParam(leftString(a,100));return new RequestData(HttpMethod.POST,"/langdetect",a)}function serviceDetectLanguageResponse(a){return(a=parseJSON(a))&&a.lan?languageFromCode(a.lan):UNKNOWN_LANGUAGE}
function serviceTranslateRequest(a,b,c){a=format("query={0}&from={1}&to={2}&transtype=trans&simple_means_flag=3",encodeURIComponent(a).replace(/%0D/g,"%0A"),codeFromLanguage(b),codeFromLanguage(c));return new RequestData(HttpMethod.POST,"/v2transapi",a)}
//function serviceTranslateResponse(a,b,c,e){var d=parseJSON(b);a="";if(d){if(d.trans_result){c=d.trans_result.data;for(b=0;b<c.length;b++)a+=c[b].dst+Const.NL;c=languageFromCode(d.trans_result.from);e=languageFromCode(d.trans_result.to)}if(d.dict_result&&d.dict_result.simple_means){var g=d.dict_result.simple_means;a+=Const.NL;a+=g.word_name;if(g&&g.symbols)for(b=0;b<g.symbols.length;b++){var f=g.symbols[b];if(f&&f.parts)for(f.word_symbol&&(a+=" ["+f.word_symbol+"]"),d=0;d<f.parts.length;d++){var h=
//f.parts[d];a+=Const.NL;h.part_name&&(a+="["+h.part_name+"] ");a+=h.means.map(function(a){return a.word_mean}).join("; ")}}}}return new ResponseData(a,c,e)}
function serviceListenRequest(a,b,c){a=format("/text2audio?lan={0}&ie=UTF-8&text={1}",codeFromLanguage(b),encodeGetParam(a));c&&(a+="&spd=1");return new RequestData(HttpMethod.GET,a)};

function serviceTranslateResponse(showContent, response, fromLanguage, toLanguage) {
    var contentJson = parseJSON(response);
    var i, j;
    showContent = "";
    if (contentJson) {
        if (contentJson.trans_result) {
            fromLanguage = contentJson.trans_result.data;
            for (i = 0; i < fromLanguage.length; i++) showContent += fromLanguage[i].dst + Const.NL;
            fromLanguage = languageFromCode(contentJson.trans_result.from);
            toLanguage = languageFromCode(contentJson.trans_result.to)
        }
        if (contentJson.dict_result && contentJson.dict_result.simple_means) {
            var meanData = contentJson.dict_result.simple_means;
            showContent += Const.NL;
            showContent += meanData.word_name;
            if (meanData && meanData.symbols)
                for (i = 0; i < meanData.symbols.length; i++) {
                    var resultList = meanData.symbols[i];
                    if (resultList && resultList.parts) {
                        if (resultList.word_symbol)  {
                            //音标(拼音)
                            showContent += " [" + resultList.word_symbol + "]";
                            for (j = 0; j < resultList.parts.length; j++) {
                                var data = resultList.parts[j];
                                showContent += Const.NL;
                                data.part_name && (showContent += "[" + data.part_name + "] ");
                                showContent += data.means.map(function (a) {
                                    return a.word_mean
                                }).join("; ")
                            }
                        } else {
                            for (j = 0; j < resultList.parts.length; j++) {
                                var data = resultList.parts[j];
                                showContent += Const.NL;
                                showContent += strFormatLen(data.part,6);
                                showContent += data.means.toString()+"; "
                            }
                        }
                    }
                }
        }
    }
    return new ResponseData(showContent, fromLanguage, toLanguage)
}